#include"line.h"

#include<iostream>

using namespace std;

int main(void){
    Line l(1,2,3,4);
    l.printline();
}
